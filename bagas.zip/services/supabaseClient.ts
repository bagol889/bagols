import { createClient } from '@supabase/supabase-js';

// Helper to safely get env vars without crashing if process is undefined
const getEnv = (key: string) => {
  try {
    return process.env[key];
  } catch (e) {
    return undefined;
  }
};

const SUPABASE_URL = getEnv('SUPABASE_URL') || 'https://ijzffgwsjkrdryarpcqp.supabase.co';
const SUPABASE_ANON_KEY = getEnv('SUPABASE_ANON_KEY') || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlqemZmZ3dzamtyZHJ5YXJwY3FwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxODcwOTQsImV4cCI6MjA3ODc2MzA5NH0.vRrHKPY7EYdZJHxki-mPh0UI1tDOMUwEzJYjj86S7rI';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export const isSupabaseConfigured = () => {
  try {
    return !!(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY);
  } catch (e) {
    return false;
  }
};