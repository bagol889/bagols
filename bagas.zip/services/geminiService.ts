import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateBotKey = async (): Promise<string> => {
  if (!apiKey) {
    console.warn("Gemini API Key missing");
    return "GEMINI_KEY_MISSING_" + Math.random().toString(36).substring(7);
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: "Generate a secure, random 32-character API key string consisting of alphanumeric characters. Return ONLY the string, no markdown, no explanation.",
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Gemini Error:", error);
    return "FALLBACK_KEY_" + Date.now();
  }
};

export const generateBotConfig = async (botType: string): Promise<string> => {
  if (!apiKey) return "{}";

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Create a JSON configuration object for a "${botType}" bot. Include fields for name, version, and 3 standard settings. Return ONLY the JSON string.`,
    });
    return response.text.replace(/```json|```/g, '').trim();
  } catch (error) {
    console.error("Gemini Error:", error);
    return JSON.stringify({ error: "Failed to generate config" });
  }
};
